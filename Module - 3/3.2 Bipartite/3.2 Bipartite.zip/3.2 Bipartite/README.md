Odd cycles. Prove that a graph is two-colorable (bipartite) if and only if it contains no odd-length cycle.

Input Format :
First line of input contains number of Vertices.
Second line of input contains number of Edges.
From third line onwards, each line contains two vertices separated by space, which are to be connected in Undirected Graph.

Output Format:
Either Graph is bipartite or Graph is not a bipartite


Note : Use Bag.java to store adjacent vertices, to print them in output order.