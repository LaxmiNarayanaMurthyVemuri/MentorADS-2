Implement Undirected Graph API, Adjacency matrix representation.

Input Format :
First line of input contains Vertices.
From the second line, there are integers followed by space of (Vertices X Vertices) binary matrix of Undirected Graph G. Where G[i][j] = 1 denotes there is a edge between i and j. 

Output Format:
First line should count of vertices, count of Edges.
From second line, print the vertices in order and its adjacent vertices separated by colon and space to separate adjacent vertices.


Note : Use Bag.java to store adjacent vertices, to print them in output order.